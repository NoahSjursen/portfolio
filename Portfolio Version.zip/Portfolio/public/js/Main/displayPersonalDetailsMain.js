// Function to display personal details
function displayPersonalDetails(personalDetails) {
    // Populate personal details section with data
    document.getElementById('full-name').textContent = personalDetails.fullName;
    document.getElementById('age').textContent = personalDetails.age;
    document.getElementById('country').textContent = personalDetails.country;
    document.getElementById('city').textContent = personalDetails.city;
    document.getElementById('email').textContent = personalDetails.email;
    document.getElementById('bio').textContent = personalDetails.bio;
    document.getElementById('work-status').textContent = personalDetails.workstatus;

    // Display lists of Skills, Education, and Certificates
    displayLists('skills', personalDetails.skills);
    displayLists('education', personalDetails.education);
    displayLists('certificates', personalDetails.certificates);
}


// Function to display list items for each item of Skills, Education, Certificates
function displayLists(listType, items) {
    const container = document.querySelector(`#${listType}`); // Get the container element

    // Clear the container first
    container.innerHTML = '';

    // Check if items exist
    if (items && items.length > 0) {
        // Iterate over each item and create list items
        items.forEach(item => {
            const listItem = document.createElement('li');
            listItem.textContent = item;
            container.appendChild(listItem);
        });
    } else {
        // If no items found, display a message
        container.innerHTML = '<li>No items found</li>';
    }
}


// Fetch personal details from Firestore
function fetchPersonalDetails() {
    let uid = localStorage.getItem('uid'); // Default to stored UID

    // Extract UID from URL if available
    const urlParams = new URLSearchParams(window.location.search);
    const urlUid = urlParams.get('uid');
    if (urlUid) {
        uid = urlUid;
    }

    if (!uid) {
        console.error('User ID not found in local storage or URL');
        return;
    }

    firestore.collection('users').doc(uid)
        .collection('PersonalPage').doc('PersonalPageID').get()
        .then((doc) => {
            if (doc.exists) {
                // Personal details found, display them
                const personalDetails = doc.data();
                displayPersonalDetails(personalDetails);
            } else {
                console.log("Personal details not found");
            }
        })
        .catch((error) => {
            console.error('Error fetching personal details: ', error);
        });
}


// Call fetchPersonalDetails() to display personal details when the page loads
fetchPersonalDetails();
