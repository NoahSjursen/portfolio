// Function to fetch projects from Firestore
function fetchProjects() {
    const uid = localStorage.getItem('uid');
    if (!uid) {
        console.error('User ID not found in local storage');
        return;
    }

    firestore.collection('users').doc(uid).collection('PersonalPage').doc('PersonalPageID').collection('Projects').get()
        .then((querySnapshot) => {
            const projectsOngoing = [];
            const projectsFinished = [];

            const addedProjects = {}; // Create an object to keep track of added project IDs

            querySnapshot.forEach((doc) => {
                const projectData = doc.data();
                if (!addedProjects[doc.id]) {
                    addedProjects[doc.id] = true; // Add the project ID to the object
                    if (projectData.projectStatus === 'ongoing') {
                        projectsOngoing.push(projectData);
                    } else if (projectData.projectStatus === 'finished') {
                        projectsFinished.push(projectData);
                    }
                }
            });

            // Display projects in their respective sections
            displayProjects(projectsOngoing, 'projects-ongoing');
            displayProjects(projectsFinished, 'projects-finished');
        })
        .catch((error) => {
            console.error('Error fetching projects: ', error);
        });
}

// Function to display projects
function displayProjects(projects, containerId) {
    const projectContainer = document.getElementById(containerId);
    projectContainer.innerHTML = ''; // Clear existing project list

    projects.forEach((project) => {
        const projectItem = document.createElement('div');
        projectItem.classList.add('project-item');

        // Display project details
        const projectName = document.createElement('h3');
        projectName.textContent = 'Project Name: ' + project.projectName;
        projectItem.appendChild(projectName);

        const projectDescription = document.createElement('p');
        projectDescription.textContent = 'Description: ' + project.projectDescription;
        projectItem.appendChild(projectDescription);

        // Display media as images or videos
        if (project.projectMedia && project.projectMedia.length > 0) {
            const mediaContainer = document.createElement('div');
            mediaContainer.classList.add('media-container');
            project.projectMedia.forEach((mediaURL) => {
                const mediaElement = createMediaElement(mediaURL);
                mediaContainer.appendChild(mediaElement);
            });
            projectItem.appendChild(mediaContainer);
        }

        const projectLinks = document.createElement('p');
        projectLinks.textContent = 'Links: ' + project.projectLinks;
        projectItem.appendChild(projectLinks);

        const projectStatus = document.createElement('p');
        projectStatus.textContent = 'Status: ' + project.projectStatus;
        projectItem.appendChild(projectStatus);

        const projectCompletionDate = document.createElement('p');
        projectCompletionDate.textContent = 'Completion Date: ' + project.projectDate;
        projectItem.appendChild(projectCompletionDate);

        const projectNotes = document.createElement('p');
        projectNotes.textContent = 'Notes: ' + project.projectNotes; // Update property name
        projectItem.appendChild(projectNotes);

        // Add the project item to the project container
        projectContainer.appendChild(projectItem);
    });
}

// Function to create media elements (images, videos, or links)
function createMediaElement(mediaURL) {
    const mediaElement = document.createElement('div');
    
    // Check if the media is an image
    if (mediaURL.toLowerCase().endsWith('.png') || mediaURL.toLowerCase().endsWith('.jpg') || mediaURL.toLowerCase().endsWith('.jpeg') || mediaURL.toLowerCase().endsWith('.gif')) {
        const imageElement = document.createElement('img');
        imageElement.src = mediaURL;
        imageElement.classList.add('project-media'); // Add a class for styling
        mediaElement.appendChild(imageElement);
    } 
    // Check if the media is a video (you might need to expand this based on the video formats you support)
    else if (mediaURL.toLowerCase().endsWith('.mp4')) {
        const videoElement = document.createElement('video');
        videoElement.src = mediaURL;
        videoElement.controls = true; // Add controls to the video
        videoElement.classList.add('project-media'); // Add a class for styling
        mediaElement.appendChild(videoElement);
    } else {
        // If it's neither an image nor a video, just display the URL
        const linkElement = document.createElement('a');
        linkElement.href = mediaURL;
        linkElement.textContent = 'View Media';
        mediaElement.appendChild(linkElement);
    }
    
    return mediaElement;
}

// Call fetchProjects() to display projects when the page loads
fetchProjects();
