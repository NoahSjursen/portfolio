// editPersonalPage.js

// Function to fetch data from Firestore and populate the form fields
function populatePersonalPageFields() {
    // Get the current user's UID from local storage
    const uid = localStorage.getItem('uid');

    // If UID exists
    if (uid) {
        // Reference to the collection in Firestore
        const personalPageRef = firestore.collection("users").doc(uid).collection("PersonalPage");

        // Get the first document
        personalPageRef.limit(1).get().then((querySnapshot) => {
            if (!querySnapshot.empty) {
                querySnapshot.forEach((doc) => {
                    // Populate the form fields with the data from Firestore
                    const data = doc.data();
                    document.getElementById('bio').value = data.bio || '';
                    document.getElementById('banner-image').value = data.bannerImageLink || '';
                    document.getElementById('profile-picture').value = data.profilePhotoLink || '';
                    document.getElementById('name').value = data.fullName || '';
                    document.getElementById('age').value = data.age || '';
                    document.getElementById('email').value = data.email || '';
                    document.getElementById('work-status').value = data.workstatus || '';
                    document.getElementById('workplace').value = data.workplace || '';
                    document.getElementById('portfolio-introduction').value = data.portfolioIntroText || '';
                    document.getElementById('country').value = data.country || '';
                    document.getElementById('city').value = data.city || '';
                });
            } else {
                console.log("No such document!");
                // Handle the case where the document is not found
            }
        }).catch((error) => {
            console.log("Error getting documents: ", error);
        });
    } else {
        console.log("No user logged in");
    }
}


// Function to save changes to Firestore
function saveChanges() {
    const uid = localStorage.getItem('uid');
    const personalPageRef = firestore.collection("users").doc(uid).collection("PersonalPage").doc("PersonalPageID");

    // Get form values
    const bio = document.getElementById('bio').value;
    const bannerImageLink = document.getElementById('banner-image').value;
    const profilePhotoLink = document.getElementById('profile-picture').value;
    const fullName = document.getElementById('name').value;
    const age = parseInt(document.getElementById('age').value);
    const email = document.getElementById('email').value;
    const workstatus = document.getElementById('work-status').value;
    const workplace = document.getElementById('workplace').value;
    const portfolioIntroText = document.getElementById('portfolio-introduction').value;
    const country = document.getElementById('country').value;
    const city = document.getElementById('city').value;

    // Save data to Firestore
    personalPageRef.set({
        bio: bio,
        bannerImageLink: bannerImageLink,
        profilePhotoLink: profilePhotoLink,
        fullName: fullName,
        age: age,
        email: email,
        workstatus: workstatus,
        workplace: workplace,
        portfolioIntroText: portfolioIntroText,
        country: country,
        city: city
    }).then(() => {
        console.log("Document successfully written!");
    }).catch((error) => {
        console.error("Error writing document: ", error);
    });
}

// Populate form fields when the page loads
document.addEventListener('DOMContentLoaded', function () {
    populatePersonalPageFields();
});

// Save changes when the "Save Changes" button is clicked
document.getElementById('edit-personal-page-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent form submission
    saveChanges();
});
