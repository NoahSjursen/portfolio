// Function to open settings modal with local storage UID
function openSettingsModal() {
    const modal = document.getElementById('settingsModal');
    modal.style.display = 'block';
}


// Function to close settings modal
window.onclick = function(event) {
    const modal = document.getElementById('settingsModal');
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// Function to close settings modal
function closeSettingsModal() {
    const modal = document.getElementById('settingsModal');
    modal.style.display = 'none';
}

// Function to delete the PersonalPage document and its parent document (UID) under users/{UID}
function deletePersonalPage(uid, personalPageId) {
    const personalPageRef = firestore.collection('users').doc(uid).collection('PersonalPage').doc(personalPageId);
    const userDocRef = firestore.collection('users').doc(uid);

    return personalPageRef.delete()
        .then(() => {
            console.log('PersonalPage document deleted successfully');
            // Delete parent document (UID) after deleting all subcollections
            return userDocRef.collection('PersonalPage').doc(personalPageId).collection('Subcollections').get()
                .then((querySnapshot) => {
                    const deletePromises = [];
                    querySnapshot.forEach((doc) => {
                        deletePromises.push(doc.ref.delete());
                    });
                    return Promise.all(deletePromises);
                })
                .then(() => {
                    console.log('Subcollections deleted successfully');
                    // Now delete the parent document (UID)
                    return userDocRef.delete();
                })
                .then(() => {
                    console.log('Parent document (UID) deleted successfully');
                });
        })
        .catch((error) => {
            console.error('Error deleting PersonalPage document:', error);
            throw error;
        });
}


// Function to delete account and associated data from Firestore and Firebase Authentication
function deleteAccount() {
    const confirmDelete = confirm("Are you sure you want to delete your account?");
    if (confirmDelete) {
        const user = firebase.auth().currentUser; // Get the current user
        if (!user) {
            console.error('User not authenticated');
            return;
        }

        const uid = user.uid; // Get UID from Firebase Authentication

        // First, delete the PersonalPage document
        deletePersonalPage(uid, 'PersonalPageID')
            .then(() => {
                // Delete user from Firebase Authentication
                return user.delete();
            })
            .then(() => {
                // Clear local storage
                localStorage.removeItem('uid');
                // Redirect to login page or perform any other action after deletion
                alert("Account deleted successfully!");
                // Example redirection:
                window.location.href = 'index.html'; // Redirect to login page
            })
            .catch((error) => {
                console.error('Error deleting account: ', error);
                alert("An error occurred while deleting your account. Please try again later.");
            });
    }
}







